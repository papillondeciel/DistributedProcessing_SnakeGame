#pragma once
#include "Direction.h"
#include "BaseData.h"


class FromServerToClientData : BaseData
{
	unsigned int ** boardMatrix;
	Direction * directionsTable;
	Direction::point_t * playerHeadPositionTable;

public:

	FromServerToClientData();
	void operator=(const FromServerToClientData & d);

	void setPlayerHeadPosition(unsigned int playerNumber, Direction::point_t point);
	void setFromServerToClientData(unsigned int ** matrix, Direction * dirTab);
	unsigned int getCellValueFromBoardMatrix(Direction::point_t field);
	Direction getPlayerDirection_forServer(unsigned int playerNumber);
	Direction::point_t getPlayerHeadPosition(unsigned int playerNumber);

	void writeMatrix();
	void writeDirectionsTable();
	void pack(sf::Packet & package) override;
	void unpack(sf::Packet & package) override;
};